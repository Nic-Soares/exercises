1. Altere o programa movendo_elementos.py para movimentar o tanque em todas as direções, utilizando as teclas direcionais do teclado.

2. Altere o programa para que o tanque siga apenas o movimento do mouse.