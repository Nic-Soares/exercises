public class Cachorro extends Animal {
  @Override
  public void fazerBarulho() {
    System.out.println("Au au");
  }
}
