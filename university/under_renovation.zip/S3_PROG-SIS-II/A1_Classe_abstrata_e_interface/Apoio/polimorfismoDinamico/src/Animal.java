abstract class Animal1 {
  public abstract void fazerBarulho();
}
