public class testaAnimais {
  public static void main(String[] args) {
    Animal1 cachorro = new Cachorro("Bobby");
    Animal1 gato = new Gato("Tom");

    cachorro.emitirSom();
    gato.emitirSom();
  }
}
