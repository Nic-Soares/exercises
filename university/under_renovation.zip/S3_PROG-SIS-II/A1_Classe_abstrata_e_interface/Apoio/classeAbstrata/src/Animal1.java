abstract class Animal1 {
  private String nome;

  public Animal1(String nome){
    this.nome = nome;
  }

  public abstract void emitirSom();
}
