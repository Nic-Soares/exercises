public interface Calcula {
  public double Area();
  public double Perimetro();
}