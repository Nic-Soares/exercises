public class Produto {
  int cod;
  String descricao;
  double preco;

  Produto (int cod, String descricao, double preco) {
    this.cod = cod;
    this.descricao = descricao;
    this.preco = preco;
  }

}
