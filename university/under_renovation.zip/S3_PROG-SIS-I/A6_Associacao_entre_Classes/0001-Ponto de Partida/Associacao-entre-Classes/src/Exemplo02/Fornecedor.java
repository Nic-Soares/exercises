package Exemplo02;

public class Fornecedor {
  int codigo;
  String nome;
  String telefone;

  Fornecedor(int codigo, String nome, String telefone) {
    this.codigo = codigo;
    this.nome = nome;
    this.telefone = telefone;
  }
}
