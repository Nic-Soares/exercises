public class Endereco {
  String logradouro;
  int numero;
  String complemento;
  String CEP;
  String cidade;
  String estado;
}
