public class Aluno {
  int tia;
  String nome;
  Endereco endereco;
  double n1;
  double n2;
}
