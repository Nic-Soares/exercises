package Questao0001;
public class Teste1 {

  public static void main(String[] args){
    A a = new A("5");
    a.print();
  }

}
