package Questao0110;
public class TesteProduto {
    public static void main(String[] args) {

        Produto produto = new Produto("Lápis", 2.50, 5);

        System.out.println(produto.calculaValor());


    }


}
