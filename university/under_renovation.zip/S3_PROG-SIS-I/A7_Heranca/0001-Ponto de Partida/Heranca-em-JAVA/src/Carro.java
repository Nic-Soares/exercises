public class Carro extends Veiculo {
  int qtdePortas;
  public String toString(){
    return "\nProprietário: " + proprietario + "\nRENAVAM: " + renavam + "\nQtde Portas: " + qtdePortas;
  }
}
