public class Caminhao extends Veiculo{
  int qtdeEixos;
  public String toString(){
    return "\nProprietário: " + proprietario + "\nRENAVAM: " + renavam + "\nQtde Eixos: " + qtdeEixos;
  }
}
