public class Veiculo {
  int renavam;
  String proprietario;

  void transfereProprietario(String novoProprietario){
    proprietario = novoProprietario;
  }
}
