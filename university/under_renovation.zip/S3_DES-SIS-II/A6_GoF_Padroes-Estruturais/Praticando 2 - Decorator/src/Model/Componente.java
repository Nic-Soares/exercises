package Model;

// Componente abstrato
public interface Componente {
  void operacao();
}

