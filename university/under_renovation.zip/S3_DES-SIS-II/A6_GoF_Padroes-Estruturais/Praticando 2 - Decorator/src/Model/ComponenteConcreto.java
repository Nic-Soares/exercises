package Model;

// Implementação concreta do componente abstrato
public class ComponenteConcreto implements Componente {
  public void operacao() {
    System.out.println("Operação do componente concreto.");
  }
}
