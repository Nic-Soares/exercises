package Praticing.CriacaoPersonagem;

// Interface para a abstração
public interface Personagem {
  void setAvatar(Avatar avatar);
  void apresentar();
}

