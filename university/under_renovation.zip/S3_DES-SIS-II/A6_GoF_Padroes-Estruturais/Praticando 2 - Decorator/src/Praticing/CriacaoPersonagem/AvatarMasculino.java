package Praticing.CriacaoPersonagem;

// Classe concreta para a implementação masculina
public class AvatarMasculino implements Avatar {
  @Override
  public void apresentar() {
    System.out.println("Superpadrãozinho (Masculino)");
  }
}
