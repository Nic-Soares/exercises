package Praticing.CriacaoPersonagem;

// Classe concreta para a implementação feminina
public class AvatarFeminino implements Avatar {
  @Override
  public void apresentar() {
    System.out.println("Superpadrãozinho (Feminino)");
  }
}
