package Praticing.CriacaoPersonagem;

// Interface para a implementação
public interface Avatar {
  void apresentar();
}
