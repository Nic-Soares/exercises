package Example;

public class Cafe implements Bebida {
  public String getDescricao() {
    return "Café";
  }

  public double getCusto() {
    return 2.0;
  }
}
