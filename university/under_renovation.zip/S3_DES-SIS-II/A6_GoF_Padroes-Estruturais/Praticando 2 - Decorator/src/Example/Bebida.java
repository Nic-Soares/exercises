package Example;

public interface Bebida {
  String getDescricao();
  double getCusto();
}

