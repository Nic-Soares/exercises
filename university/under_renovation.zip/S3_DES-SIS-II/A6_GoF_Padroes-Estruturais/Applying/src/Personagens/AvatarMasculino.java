package Personagens;

public class AvatarMasculino implements Avatar {
  @Override
  public void apresentar() {
    System.out.print("(Masculino) ");
  }
}
