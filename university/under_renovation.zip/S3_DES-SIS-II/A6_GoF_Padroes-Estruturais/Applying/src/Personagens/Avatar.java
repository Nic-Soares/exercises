package Personagens;

public interface Avatar {
  void apresentar();
}
