package CenariosAnimaisVegetacao.ConcreteComponent;

import CenariosAnimaisVegetacao.AbstractComponent.Cenario;

public class SelvaJurassica implements Cenario {
  public void descrição() {
    System.out.println("Você está na selva jurássica");
  }
}
