package CenariosAnimaisVegetacao.ConcreteComponent;

import CenariosAnimaisVegetacao.AbstractComponent.Cenario;

public class Deserto implements Cenario {
  public void descrição() {
    System.out.println("Você está no deserto");
  }
}
