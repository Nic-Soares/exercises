package CenariosAnimaisVegetacao.ConcreteComponent;

import CenariosAnimaisVegetacao.AbstractComponent.Cenario;

public class FundoOceano implements Cenario {
  public void descrição() {
    System.out.println("Você está no fundo do oceano");
  }
}
