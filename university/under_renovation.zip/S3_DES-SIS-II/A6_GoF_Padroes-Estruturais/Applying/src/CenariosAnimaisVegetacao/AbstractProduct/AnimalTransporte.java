package CenariosAnimaisVegetacao.AbstractProduct;

public interface AnimalTransporte {
  public void transporting();
}
