package CenariosAnimaisVegetacao.AbstractProduct;

public interface AnimalPerigoso {
  public void attack();
}
