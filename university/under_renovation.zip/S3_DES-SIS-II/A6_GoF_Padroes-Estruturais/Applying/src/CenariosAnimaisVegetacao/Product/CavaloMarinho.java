package CenariosAnimaisVegetacao.Product;

import CenariosAnimaisVegetacao.AbstractProduct.*;

public class CavaloMarinho implements AnimalTransporte {
  public void transporting(){
    System.out.println("O Cavalo Marinho nos transporta nadando");
  }
}