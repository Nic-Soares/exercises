package CenariosAnimaisVegetacao.Product;

import CenariosAnimaisVegetacao.AbstractProduct.*;

public class TubarãoBranco implements AnimalPerigoso {
  public void attack() {
    System.out.println("O Tubarão Branco está atacando");
  }
}
