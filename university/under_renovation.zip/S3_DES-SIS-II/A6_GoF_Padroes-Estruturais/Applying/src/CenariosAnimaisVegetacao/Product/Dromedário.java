package CenariosAnimaisVegetacao.Product;

import CenariosAnimaisVegetacao.AbstractProduct.*;

public class Dromedário implements AnimalTransporte {
  public void transporting(){
    System.out.println("O Dromedário nos transporta andando");
  }
}
