package CenariosAnimaisVegetacao.Product;

import CenariosAnimaisVegetacao.AbstractProduct.*;

public class TRex implements AnimalPerigoso {
  public void attack() {
    System.out.println("A T-Rex está atacando");
  }
}
