package CenariosAnimaisVegetacao.AbstractComponent;

public interface Cenario {
  public void descrição();
}
