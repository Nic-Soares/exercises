package Model;

// Implementação específica da interface Bridge
class ImplementadorConcretoA implements Implementador {
  public void operacaoImplementada() {
    System.out.println("Operação implementada pelo ImplementadorConcretoA.");
  }
}
