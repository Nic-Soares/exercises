package Model;

// Implementação da interface Bridge
interface Implementador {
  public void operacaoImplementada();
}

