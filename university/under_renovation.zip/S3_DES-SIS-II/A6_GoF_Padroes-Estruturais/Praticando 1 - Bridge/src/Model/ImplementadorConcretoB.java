package Model;

// Outra implementação específica da interface Bridge
class ImplementadorConcretoB implements Implementador {
  public void operacaoImplementada() {
    System.out.println("Operação implementada pelo ImplementadorConcretoB.");
  }
}
