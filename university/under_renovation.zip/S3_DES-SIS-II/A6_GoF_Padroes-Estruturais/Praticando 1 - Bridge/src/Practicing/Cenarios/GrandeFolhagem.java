package Practicing.Cenarios;

public class GrandeFolhagem implements Vegetacao {
  public void adicionarVegetacao() {
    System.out.println("Grande folhagem adicionada ao cenário da floresta jurássica");
  }
}
