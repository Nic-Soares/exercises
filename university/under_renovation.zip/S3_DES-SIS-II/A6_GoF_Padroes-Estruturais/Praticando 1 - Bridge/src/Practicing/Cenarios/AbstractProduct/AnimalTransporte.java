package Practicing.Cenarios.AbstractProduct;

public interface AnimalTransporte {
  public void transporting();
}
