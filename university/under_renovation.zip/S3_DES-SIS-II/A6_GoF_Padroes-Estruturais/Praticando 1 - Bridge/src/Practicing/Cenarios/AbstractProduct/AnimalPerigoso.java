package Practicing.Cenarios.AbstractProduct;

public interface AnimalPerigoso {
  public void attack();
}
