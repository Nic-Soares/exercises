package Practicing.Cenarios;

public class ArvoreGigante implements Vegetacao {
  public void adicionarVegetacao() {
    System.out.println("Árvore gigante adicionada ao cenário da floresta jurássica");
  }
}
