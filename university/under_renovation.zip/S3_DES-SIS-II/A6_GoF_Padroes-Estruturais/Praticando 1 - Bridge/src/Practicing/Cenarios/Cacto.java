package Practicing.Cenarios;

public class Cacto implements Vegetacao {
  public void adicionarVegetacao() {
    System.out.println("Cacto adicionado ao cenário do deserto");
  }
}

