package Practicing.Cenarios;

public class Algas implements Vegetacao {
  public void adicionarVegetacao() {
    System.out.println("Algas adicionadas ao cenário do oceano");
  }
}
