package Practicing.Cenarios;

public class Arbusto implements Vegetacao {
  public void adicionarVegetacao() {
    System.out.println("Arbusto adicionado ao cenário do deserto");
  }
}
