package Practicing.Cenarios;

public class Cogumelo implements Vegetacao {
  public void adicionarVegetacao() {
    System.out.println("Cogumelo adicionado ao cenário do oceano");
  }
}
