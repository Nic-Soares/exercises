package Practicing.Cenarios;

public interface Vegetacao {
  public void adicionarVegetacao();
}
