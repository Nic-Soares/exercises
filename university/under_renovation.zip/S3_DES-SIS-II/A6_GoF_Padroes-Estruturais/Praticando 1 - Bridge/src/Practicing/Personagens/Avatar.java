package Practicing.Personagens;

public interface Avatar {
  void apresentar();
}
