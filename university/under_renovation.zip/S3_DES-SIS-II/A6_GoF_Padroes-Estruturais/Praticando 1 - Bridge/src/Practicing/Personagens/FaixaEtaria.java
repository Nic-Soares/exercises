package Practicing.Personagens;

public interface FaixaEtaria {
  String getDescricao();
}

