package Practicing.Personagens;

public class Adulto implements FaixaEtaria {
  @Override
  public String getDescricao() {
    return "Adulto";
  }
}
