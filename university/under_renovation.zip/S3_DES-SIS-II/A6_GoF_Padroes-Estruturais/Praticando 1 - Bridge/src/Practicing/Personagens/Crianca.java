package Practicing.Personagens;

public class Crianca implements FaixaEtaria {
  @Override
  public String getDescricao() {
    return "Criança";
  }
}
