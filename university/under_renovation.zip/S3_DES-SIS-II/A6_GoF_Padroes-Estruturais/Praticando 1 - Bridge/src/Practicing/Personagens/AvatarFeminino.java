package Practicing.Personagens;

public class AvatarFeminino implements Avatar {
  @Override
  public void apresentar() {
    System.out.print("(Feminino) ");
  }
}
