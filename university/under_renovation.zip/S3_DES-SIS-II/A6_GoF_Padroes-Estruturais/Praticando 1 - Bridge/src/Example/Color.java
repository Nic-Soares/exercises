package Example;

public interface Color {
  String fill();
}
