package Example;

public class GreenColor implements Color{
  public String fill(){
    return "Color is Green";
  }
}
