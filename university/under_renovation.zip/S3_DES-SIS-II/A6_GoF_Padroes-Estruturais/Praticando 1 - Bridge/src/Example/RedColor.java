package Example;

public class RedColor implements Color{
  public String fill() {
    return "Color is Red";
  }
}
