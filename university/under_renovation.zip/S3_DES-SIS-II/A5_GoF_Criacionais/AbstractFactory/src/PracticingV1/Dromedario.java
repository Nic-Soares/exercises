package PracticingV1;

// Implementação do dromedário, que é um animal de transporte do deserto
public class Dromedario implements AnimalTransporte {
  public void cavalgar() {
    System.out.println("Cavalgando no dromedário!");
  }
}
