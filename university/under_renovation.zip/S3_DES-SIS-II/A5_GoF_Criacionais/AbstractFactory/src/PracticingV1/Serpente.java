package PracticingV1;

// Implementação da serpente, que é um animal perigoso do deserto
public class Serpente implements AnimalPerigoso {
  public void atacar() {
    System.out.println("A serpente ataca!");
  }
}
