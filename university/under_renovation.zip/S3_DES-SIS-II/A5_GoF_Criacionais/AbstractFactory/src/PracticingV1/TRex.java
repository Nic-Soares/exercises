package PracticingV1;

// Implementação do T-Rex, que é um animal perigoso da selva jurássica
public class TRex implements AnimalPerigoso {
  public void atacar() {
    System.out.println("O T-Rex ataca!");
  }
}
