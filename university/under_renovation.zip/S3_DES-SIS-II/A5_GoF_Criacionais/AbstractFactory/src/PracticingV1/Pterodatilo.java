package PracticingV1;

// Implementação do Pterodátilo, que é um animal de transporte da selva jurássica
public class Pterodatilo implements AnimalTransporte {
  public void cavalgar() {
    System.out.println("Voando no Pterodátilo!");
  }
}
