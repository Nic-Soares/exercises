package PracticingV1;

// Interface para animais perigosos
public interface AnimalPerigoso {
  void atacar();
}
