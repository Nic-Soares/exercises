package PracticingV1;

// Interface para animais de transporte
public interface AnimalTransporte {
  void cavalgar();
}
