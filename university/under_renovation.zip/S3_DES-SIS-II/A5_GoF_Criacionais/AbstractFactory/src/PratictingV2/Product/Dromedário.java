package PratictingV2.Product;

import PratictingV2.AbstractProduct.AnimalTransporte;

public class Dromedário implements AnimalTransporte {
  public void transporting(){
    System.out.println("O Dromedário nos transporta andando");
  }
}
