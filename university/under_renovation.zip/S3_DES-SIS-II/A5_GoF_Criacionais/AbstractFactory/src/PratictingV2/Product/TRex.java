package PratictingV2.Product;

import PratictingV2.AbstractProduct.AnimalPerigoso;

public class TRex implements AnimalPerigoso {
  public void attack() {
    System.out.println("A T-Rex está atacando");
  }
}
