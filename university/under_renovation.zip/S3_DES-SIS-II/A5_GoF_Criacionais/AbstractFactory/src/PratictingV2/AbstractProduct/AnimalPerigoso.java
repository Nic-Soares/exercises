package PratictingV2.AbstractProduct;

public interface AnimalPerigoso {
  public void attack();
}
