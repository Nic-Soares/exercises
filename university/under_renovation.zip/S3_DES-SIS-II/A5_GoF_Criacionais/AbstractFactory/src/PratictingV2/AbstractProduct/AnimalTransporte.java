package PratictingV2.AbstractProduct;

public interface AnimalTransporte {
  public void transporting();
}
