package Example.AbstractProduct;

public interface Carnivore extends Animal{
}
