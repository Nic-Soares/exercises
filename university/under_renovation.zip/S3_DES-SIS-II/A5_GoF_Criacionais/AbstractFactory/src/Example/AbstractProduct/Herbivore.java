package Example.AbstractProduct;

public interface Herbivore extends Animal{
}
