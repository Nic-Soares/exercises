package Example.AbstractProduct;

interface Animal {
  public void eat();
}
