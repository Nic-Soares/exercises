package Example.Product;

import Example.AbstractProduct.Herbivore;

public class Bison implements Herbivore {
  public void eat() {
    System.out.println("The bison is eating grass.");
  }
}
