package Example.Product;

import Example.AbstractProduct.Carnivore;

public class Lion implements Carnivore {
  public void eat() {
    System.out.println("The lion is eating meat.");
  }
}
