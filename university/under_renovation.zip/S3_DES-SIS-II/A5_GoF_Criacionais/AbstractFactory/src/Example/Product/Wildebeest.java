package Example.Product;

import Example.AbstractProduct.Herbivore;

public class Wildebeest implements Herbivore {
  public void eat() {
    System.out.println("The wildebeest is eating grass");
  }
}
