package Example.Product;

import Example.AbstractProduct.Carnivore;

public class Wolf implements Carnivore {
  public void eat() {
    System.out.println("The wolf is eating meat.");
  }
}
