package ApplyingKnowledge.Product;

import ApplyingKnowledge.AbstractProduct.AnimalPerigoso;

public class TRex implements AnimalPerigoso {
  public void attack() {
    System.out.println("A T-Rex está atacando");
  }
}
