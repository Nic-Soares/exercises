package ApplyingKnowledge.Product;

import ApplyingKnowledge.AbstractProduct.AnimalPerigoso;

public class TubarãoBranco implements AnimalPerigoso {
  public void attack() {
    System.out.println("O Tubarão Branco está atacando");
  }
}
