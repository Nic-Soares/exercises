package ApplyingKnowledge.Product;

import ApplyingKnowledge.AbstractProduct.AnimalTransporte;

public class CavaloMarinho implements AnimalTransporte {
  public void transporting(){
    System.out.println("O Cavalo Marinho nos transporta nadando");
  }
}