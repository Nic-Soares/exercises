package ApplyingKnowledge.Product;

import ApplyingKnowledge.AbstractProduct.AnimalTransporte;

public class Pterodátilo implements AnimalTransporte {
  public void transporting(){
    System.out.println("O Pterodátilo nos transporta voando");
  }
}
