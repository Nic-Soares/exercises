package ApplyingKnowledge.Product;

import ApplyingKnowledge.AbstractProduct.AnimalTransporte;

public class Dromedário implements AnimalTransporte {
  public void transporting(){
    System.out.println("O Dromedário nos transporta andando");
  }
}
