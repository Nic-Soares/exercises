package ApplyingKnowledge.Product;

import ApplyingKnowledge.AbstractProduct.AnimalPerigoso;

public class Serpente implements AnimalPerigoso {
  public void attack() {
    System.out.println("A Serpente está atacando");
  }
}
