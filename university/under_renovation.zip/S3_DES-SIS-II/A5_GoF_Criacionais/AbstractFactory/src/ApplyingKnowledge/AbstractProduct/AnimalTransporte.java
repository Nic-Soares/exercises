package ApplyingKnowledge.AbstractProduct;

public interface AnimalTransporte {
  public void transporting();
}
