package ApplyingKnowledge.AbstractProduct;

public interface AnimalPerigoso {
  public void attack();
}
