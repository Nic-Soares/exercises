package Model;

// Interface para o produto B
public interface AbstractProductB {
  public String getName();
}
