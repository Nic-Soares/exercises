package Model;

// Implementação do produto B2
public class ProductB2 implements AbstractProductB {
  public String getName() {
    return "Product B2";
  }
}
