package Model;

// Implementação do produto A2
public class ProductA2 implements AbstractProductA {
  public String getName() {
    return "Product A2";
  }
}
