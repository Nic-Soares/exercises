package Model;

// Interface para o produto A
public interface AbstractProductA {
  public String getName();
}