package Model;

// Implementação do produto A1
public class ProductA1 implements AbstractProductA {
  public String getName() {
    return "Product A1";
  }
}
