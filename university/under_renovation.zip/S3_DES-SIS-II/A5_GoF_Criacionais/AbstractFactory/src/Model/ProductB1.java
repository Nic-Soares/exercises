package Model;

// Implementação do produto B1
public class ProductB1 implements AbstractProductB {
    public String getName() {
        return "Product B1";
    }
}