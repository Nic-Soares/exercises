// Interface que define o comportamento geral dos cenários
public interface Cenario {
  void iniciar();
}

