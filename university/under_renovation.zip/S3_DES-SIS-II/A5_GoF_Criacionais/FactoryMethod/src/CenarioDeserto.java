// Implementação concreta da interface Cenario para o cenário do deserto
public class CenarioDeserto implements Cenario {
  @Override
  public void iniciar() {
    // Implementação do início do cenário do deserto
  }
}
