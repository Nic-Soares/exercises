// Implementação concreta da interface Cenario para o cenário da selva jurássica
public class CenarioSelvaJurassica implements Cenario {
  @Override
  public void iniciar() {
    // Implementação do início do cenário da selva jurássica
  }
}
