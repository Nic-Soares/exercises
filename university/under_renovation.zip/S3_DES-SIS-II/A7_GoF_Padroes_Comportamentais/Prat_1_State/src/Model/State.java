package Model;

// Interface para todos os estados
interface State {
  void handle();
}

