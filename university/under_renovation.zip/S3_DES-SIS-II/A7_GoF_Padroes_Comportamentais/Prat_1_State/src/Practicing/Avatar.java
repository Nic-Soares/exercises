package Practicing;

public interface Avatar {
  void apresentar();
}
