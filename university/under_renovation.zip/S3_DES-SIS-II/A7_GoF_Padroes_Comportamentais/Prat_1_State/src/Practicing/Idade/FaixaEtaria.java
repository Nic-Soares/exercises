package Practicing.Idade;

public interface FaixaEtaria {
  String getDescricao();
}

