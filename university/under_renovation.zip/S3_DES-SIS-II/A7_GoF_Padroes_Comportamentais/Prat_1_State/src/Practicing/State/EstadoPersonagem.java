package Practicing.State;

public interface EstadoPersonagem {
  void receberAtaque();
  void curar();
}
