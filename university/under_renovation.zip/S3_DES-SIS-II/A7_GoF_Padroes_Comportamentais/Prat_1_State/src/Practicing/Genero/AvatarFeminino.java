package Practicing.Genero;

import Practicing.Avatar;

public class AvatarFeminino implements Avatar {
  @Override
  public void apresentar() {
    System.out.print("(Feminino) ");
  }
}
