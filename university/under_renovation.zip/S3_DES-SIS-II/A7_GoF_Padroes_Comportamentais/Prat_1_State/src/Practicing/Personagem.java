package Practicing;

import Practicing.Idade.FaixaEtaria;

public interface Personagem {
  void setAvatar(Avatar avatar);

  void setFaixaEtaria(FaixaEtaria faixaEtaria);

  void apresentar();
}
