package Example;

// Interface que define os métodos que cada estado deve implementar
public interface EstadoVeiculo {
  void acelerar();

  void frear();

  void parar();
}
