package CriacaoPersonagem.State;

public interface EstadoPersonagem {
  void receberAtaque();
  void curar();
}
