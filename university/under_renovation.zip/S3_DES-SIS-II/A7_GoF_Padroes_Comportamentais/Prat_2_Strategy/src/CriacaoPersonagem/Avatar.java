package CriacaoPersonagem;

public interface Avatar {
  void apresentar();
}
