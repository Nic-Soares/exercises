package CriacaoPersonagem.Idade;

public class Adulto implements FaixaEtaria {
  @Override
  public String getDescricao() {
    return "Adulto";
  }
}

