package CriacaoPersonagem.Idade;

public interface FaixaEtaria {
  String getDescricao();
}

