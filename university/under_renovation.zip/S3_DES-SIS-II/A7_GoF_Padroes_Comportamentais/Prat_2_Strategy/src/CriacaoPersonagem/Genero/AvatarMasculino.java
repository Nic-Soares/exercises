package CriacaoPersonagem.Genero;

import Practicing.Avatar;

public class AvatarMasculino implements Avatar {
  @Override
  public void apresentar() {
    System.out.print("(Masculino) ");
  }
}
