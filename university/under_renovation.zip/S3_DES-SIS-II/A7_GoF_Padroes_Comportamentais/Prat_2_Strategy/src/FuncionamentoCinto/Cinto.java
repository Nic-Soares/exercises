package FuncionamentoCinto;

// Interface para o componente base (cinto)
public interface Cinto {
  void usar();
}

