package FuncionamentoCinto.Strategy;

public interface Arma {
  void atacar();
  void defender();
}

