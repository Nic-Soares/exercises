package Done;

public class Testa {
  public static void main(String[] args) {
    Curso curso1 = new Curso("ADS", "Graduação", false, false, 2024, null);
    Matricula matricula1 = new Matricula(123456, true, 920.50, 20.5, curso1);
    Aluno aluno1 = new Aluno("Martin Fowler", matricula1);

    Curso curso2 = new Curso("Computação Aplicada", "Mestrado", true, true, 2019, new Trabalho("Impacto da Refatoração", "Peter Coad", 9.5));
    Matricula matricula2 = new Matricula(654321, false, 2150.45, 0, curso2);
    Aluno aluno2 = new Aluno("Kent Beck", matricula2);

    System.out.println(aluno1.getDados());
    System.out.println(aluno2.getDados());
  }
}
